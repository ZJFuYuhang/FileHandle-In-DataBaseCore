#include "datadic.h"

DataDic::DataDic(int oid,const char* fileName):oid(oid),fileName(fileName)
{
    this->curPageNum = 40;//��ʼ�ļ�ҳ����
}

DataDic::~DataDic()
{
    //dtor
}
