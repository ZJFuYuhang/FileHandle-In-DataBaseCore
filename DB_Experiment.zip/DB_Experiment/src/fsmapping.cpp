#include "fsmapping.h"

FSMapping::FSMapping()
{
    //ctor
}
FSMapping::~FSMapping()
{
    //dtor
}
int FSMapping::GetFSMFileName(const char*fileName,string &fileName_FSM)
{
    fileName_FSM = std::string(fileName);
    fileName_FSM.append(".fsm");
    if(fileName_FSM.size() > 100)
        return -1;
    return 0;
}

int FSMapping::FindForPageNum(int datasize,int linps,int& index)
{
    int DR = (datasize+31)/32;
    index = 0;
    for(index=0; index<pageSum; index++)
    {
        if(DR<(int)FSList[index]&&(int)linpList[index]>linps)
        {
            return 0;
        }
    }
    index=-1;
    return 0;
}

int FSMapping::UpdateFSM(int index,int leftSpace,int linps)
{
    if(linps>linpList[index])
    {
        return -1;
    }
    FSList[index] =(char)((leftSpace+31)/32);
    linpList[index]=(char)((int)linpList[index]-linps);
    return 0;
}
int FSMapping::Init(FILE* fp)
{

    //�ļ���д������
    int numBytes=0;
    //�м�����
    int dataDic = 0;
    if((numBytes=fread(&dataDic,sizeof(int),1,fp))!=1)
    {
        if(numBytes<0)
        {
            return -1;
        }
        else
        {
            return -1;
        }
    }
    pageSum = dataDic;
    FSList = new char[pageSum];
    linpList = new char[pageSum];
    if((numBytes=fread(FSList,(pageSum*sizeof(char)),1,fp))!=1)
    {
        if(numBytes<0)
        {
            return -1;
        }
        else
        {
            return -1;
        }
    }
    if((numBytes=fread(linpList,(pageSum*sizeof(char)),1,fp))!=1)
    {
        if(numBytes<0)
        {
            return -1;
        }
        else
        {
            return -1;
        }
    }
    return 0;
}
int FSMapping::Flush(FILE* fp)
{
    //�ļ���д������
    int numBytes=0;
    //д���ļ�
    //��ͷ��¼ҳ����
    if((numBytes=fwrite(&pageSum,sizeof(int),1,fp))!=1)
    {
        if(numBytes<0)
        {
            return -1;
        }
        else
        {
            return -1;
        }
    }
    if((numBytes=fwrite(FSList,(pageSum*sizeof(char)),1,fp))!=1)
    {
        if(numBytes<0)
        {
            return -1;
        }
        else
        {
            return -1;
        }
    }
    if((numBytes=fwrite(linpList,(pageSum*sizeof(char)),1,fp))!=1)
    {
        if(numBytes<0)
        {
            return -1;
        }
        else
        {
            return -1;
        }
    }
    return 0;
}
int FSMapping::print()
{
    cout<<"FSM��������"<<pageSum<<endl;
    cout<<"����Ϊ���пռ�ȼ���ʣ��linp����"<<endl;
    for(int i=0; i<pageSum; i++)
    {
        cout<<(int)FSList[i]<<"  "<<(int)linpList[i]<<endl;
    }
    return 0;
}

int FSMapping::Expand()
{
    char* new_FSList = NULL;
    char* new_linpList = NULL;
    int new_pageSum = pageSum *2;
    new_FSList = new char[new_pageSum];
    new_linpList = new char[new_pageSum];
    for(int i=0; i<pageSum; i++)
    {
        new_FSList[i] = FSList[i];
        new_linpList[i] = linpList[i];
    }
    for(int i=pageSum; i<new_pageSum; i++)
    {
        new_FSList[i] = (char)((Global::pageSize-sizeof(PageHeader)+31)/32);
        new_linpList[i] =(char)100;
    }
    delete[] linpList;
    delete[] FSList;
    linpList = new_linpList;
    FSList = new_FSList;
    pageSum = new_pageSum;
    new_linpList = NULL;
    new_FSList = NULL;
    return 0;
}
int FSMapping::FindForEmptyPage(int &pageNum)
{
    int index = 0;
    for(index; index<pageSum; index++)
    {
        if((FSList[index]==((char)((Global::pageSize-sizeof(PageHeader)+31)/32)))&&(linpList[index]==(char)100))
        {
            pageNum = index;
            break;
        }
    }
    if(index==pageSum){
        pageNum = NOEMPTYPAGE;
    }
    return 0;
}
