#include "filemgr.h"
FileMgr::FileMgr()
{
    pBufferMgr = new BufferMgr(Global::numPages_Buffer);
}
FileMgr::~FileMgr()
{

}

int FileMgr::CreateFile(const char *fileName,DataDic& dataDic)
{

    //�ļ�д��״̬�ж�������ֵ
    int numBytes=0;
    int rc = 0;
    FILE *fp = NULL;
    char* mid = NULL;
    const int ph_size = sizeof(PageHeader);

    /*
        ��ͷ����ļ��Ƿ���ڡ�
        oi.h���_access����
        ����ϵͳAPI
        fstream(,ios::in);
        boost����ĺ���
    */
//����FSM
    string fileName_FSM;
    if((rc=FSMapping::GetFSMFileName(fileName,fileName_FSM)))
    {
        return rc;
    }
    if((_access(fileName_FSM.c_str(),0))!= -1)
    {
        return -1;
    }
    if((fp=fopen(fileName_FSM.c_str(),"wb"))==NULL)
    {
        return -1;
    }
    if((numBytes=fwrite(&dataDic.curPageNum,sizeof(int),1,fp))!=1)
    {
        remove(fileName_FSM.c_str());
        return -1;
    }

    mid = new char[dataDic.curPageNum];
    memset(mid,(Global::pageSize-sizeof(PageHeader)+31)/32,sizeof(char)*dataDic.curPageNum);
    if((numBytes=fwrite(mid,sizeof(char)*dataDic.curPageNum,1,fp))!=1)
    {
        remove(fileName_FSM.c_str());
        delete[] mid;
        mid = NULL;
        return -1;
    }
    memset(mid,100,sizeof(char)*dataDic.curPageNum);
    if((numBytes=fwrite(mid,sizeof(char)*dataDic.curPageNum,1,fp))!=1)
    {
        remove(fileName_FSM.c_str());
        delete[] mid;
        mid = NULL;
        return -1;
    }
    delete[] mid;
    mid = NULL;
    if(fclose(fp)<0)
    {
        return -1;
    }
    fp = NULL;
//���ݱ����
    if((_access(fileName,0))!= -1)
    {
        return -1;
    }
    if((fp=fopen(fileName,"wb"))==NULL)
    {
        return -1;
    }
    //���ټȶ���С�Ĵ��̿�ռ�
    //��������ָ��
    char * data_chars=NULL;
    //���ģ��
    PageHeader phd;
    //��ʼ���ṹ������
    phd.init();
    //�������黯
    data_chars = phd.parseObjToChars();

    /*������
    //��ӡһ��ģ���������
    phd.print();
    cout<<endl;
    */

    //д���ļ�
    mid = new char[Global::pageSize-ph_size];
    memset(mid,0,Global::pageSize-ph_size);
    for(int i=0; i<dataDic.curPageNum; i++)
    {
        if((numBytes=fwrite(data_chars,ph_size,1,fp))!=1)
        {
            remove(fileName);
            return -1;
        }

        if((numBytes=fwrite(mid,(Global::pageSize-ph_size)*sizeof(char),1,fp))!=1)
        {
            remove(fileName);
            return -1;
        }
    }
    delete[] mid;
    mid = NULL;
    /*������
    fclose(fp);
    fp=fopen(fileName,"rb");
    PageHeader* data_struct;
    char* chars_test= NULL;
    //��ӡд���ļ�����
    data_struct=PageHeader::parseCharsToObj(data_chars);
    data_struct->print();
    delete[] data_struct;

    data_struct = NULL;
    chars_test = new char[ph_size];
    fread(chars_test,ph_size,1,fp);
    data_struct=PageHeader::parseCharsToObj(chars_test);
    data_struct->print();
    delete[] chars_test;
    chars_test = NULL;
    delete[] data_struct;
    data_struct = NULL;
    */
    if(fclose(fp)<0)
    {
        return -1;
    }
    delete[] data_chars;
    data_chars = NULL;
    return 0;
}


int FileMgr::DestroyFile (const char *fileName)
{
    string fileName_FSM;
    int rc = 0;
    if (remove(fileName) < 0)
        return -1;
    if((rc = FSMapping::GetFSMFileName(fileName,fileName_FSM)))
    {
        return rc;
    }
    if (remove(fileName_FSM.c_str()) < 0)
        return -1;
    return 0;
}


int FileMgr::OpenFile (const char *fileName, FileHandle &fileHandle,DataDic &dataDic)
{
    int rc = 0;
    //����ļ��Ƿ��
    if(!fileHandle.bFileOpen)
    {
        return -1;
    }
    //���ļ�
    if ((fileHandle.osfp = fopen(fileName,"r+b")) ==NULL)
        return -1;
    //�ó�Ա������¼�ı�������
    fileHandle.bHdrChanged = 0;
    fileHandle.pBufferMgr = pBufferMgr;
    fileHandle.pDataDic = &dataDic;
    FILE *fp =NULL;
    string fileName_FSM;
    if((rc= FSMapping::GetFSMFileName(fileName,fileName_FSM))){
        return rc;
    }
    if((fp=fopen(fileName_FSM.c_str(),"wb"))==NULL)
    {
        return -1;
    }
    fileHandle.FSM.Init(fp);
    if (fclose(fp) < 0)
        return -1;
    fp = NULL;
    //�ļ��Ƿ��
    fileHandle.bFileOpen = true;
    return 0;
}
int FileMgr::CloseFile(FileHandle &fileHandle)
{
    int rc = 0;
    if (!fileHandle.bFileOpen)
        return -1;
    FILE *fp =NULL;
    string fileName_FSM;
    if((rc=FSMapping::GetFSMFileName(fileHandle.pDataDic->fileName,fileName_FSM))){
        return rc;
    }
    if((fp=fopen(fileName_FSM.c_str(),"wb"))==NULL)
    {
        return -1;
    }
    fileHandle.FSM.Flush(fp);
    if (fclose(fp) < 0)
        return -1;
    fp = NULL;

    //д����������ҳ
    if ((rc = fileHandle.FlushPages()))
        return -1;
    fileHandle.bHdrChanged = 0;
    if (fclose(fileHandle.osfp) < 0)
        return -1;
    fileHandle.bFileOpen = false;
    fileHandle.pBufferMgr = NULL;
    fileHandle.pDataDic = NULL;
    return 0;
}
