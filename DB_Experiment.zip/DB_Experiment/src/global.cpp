#include "global.h"
#include <iostream>

int Global::pageSize = 4096;
int Global::numPages_Buffer = 5;
int Global::SetPageSize(int choose){
    switch(choose){
    case 1:
        pageSize = 1024*2;break;
    case 2:
        pageSize = 1024*2*2;break;
    case 3:
        pageSize = 1024*2*2*2;break;
    default:
        return -1;
    }
    return 0;
}
int Global::SetNumPages_Buffer(int num){
    numPages_Buffer = num;
    return 0;
}
