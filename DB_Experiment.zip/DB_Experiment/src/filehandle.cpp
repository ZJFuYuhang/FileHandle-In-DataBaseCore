#include "filehandle.h"

FileHandle::FileHandle(DataDic* pDataDic)
{
    //ctor
    this->pDataDic =pDataDic;
    osfp = NULL;
    bHdrChanged = 0;
    pBufferMgr = NULL;
    bFileOpen = false;
}

FileHandle::~FileHandle()
{
    //dtor
}
FileHandle::FileHandle(const FileHandle &fileHandle)
{
    this->pDataDic = fileHandle.pDataDic;
    this->pBufferMgr  = fileHandle.pBufferMgr;
    this->bFileOpen   = fileHandle.bFileOpen;
    this->bHdrChanged = fileHandle.bHdrChanged;
    this->osfp      = fileHandle.osfp;
}

FileHandle& FileHandle::operator= (const FileHandle &fileHandle)
{
    if (this != &fileHandle)
    {
        this->pDataDic  =  fileHandle.pDataDic;
        this->pBufferMgr  = fileHandle.pBufferMgr;
        this->bFileOpen   = fileHandle.bFileOpen;
        this->bHdrChanged = fileHandle.bHdrChanged;
        this->osfp     = fileHandle.osfp;
    }
    return (*this);
}
int FileHandle::GetThisPage(int pageNum, PageHandle &pageHandle) const
{

    //����ļ��Ƿ��
    if (!bFileOpen)
        return -1;

    //�ж�ҳ���Ƿ�Ϸ�
    if (!IsValidPageNum(pageNum))
        return -1;

    //����BufferMgr��ȡҳ����
    //if ((returncode = pBufferMgr->GetPage(osfd, pageNum, &pPageBuf,*this)))
    //return returncode;
    //��ʼ��PageHandle
    //���ҳ�ĺϷ����
    //������Ϸ���Ҫ����д��
    return 0;
}
int FileHandle::GetFirstPage(PageHandle &pageHandle) const
{
    return (GetThisPage(0, pageHandle));
}

int FileHandle::GetLastPage(PageHandle &pageHandle) const
{
    return (GetThisPage(Global::pageSize-1, pageHandle));
}

int FileHandle::GetNextPage(int current, PageHandle &pageHandle) const
{
    int returncode;
    if (!bFileOpen)
        return -1;
    if (!IsValidPageNum(current))
        return -1;
    returncode = GetThisPage(current+1, pageHandle);//�º��޸�Ϊ��ʹ�õ���һҳ
    return returncode;
}

int FileHandle::GetPrevPage(int current, PageHandle &pageHandle) const
{
    int returncode;
    if (!bFileOpen)
        return -1;
    if (!IsValidPageNum(current))
        return -1;
    returncode = GetThisPage(current-1, pageHandle);//�º��޸�Ϊ��ʹ�õ���һҳ
    return returncode;
}

////���ܣ����ڴ��еĿ��޷�����˴�����ʱ
////1.�����ļ��п��п�
////2.���ļ��ռ䲻�㣬�����ļ��ռ�Ϊԭ��������
//RC PF_FileHandle::AllocatePage(PF_PageHandle &pageHandle)
//{
//    int     rc;
//    int     pageNum;
//    char    *pPageBuf;
//    if (!bFileOpen)
//        return (PF_CLOSEDFILE);
//    //ͨ��FTM���ҵ�δ���صĿ��п�
//    //������������룬�����ؿ��(һ��Ϊ�߼����)
//    //���������㹻�Ŀ��пռ䣬���ļ���С����ԭ��������������һ���п�����ڴ�
//        //����ļ�
//        //���ؿ��(һ��Ϊ�߼����)
//    //��ʼ��PF_PageHandle
//    return 0;
//}
//
//
int FileHandle::AllocatePage(PageHandle &pageHandle)
{

    int rc = 0;
    int pageNum;
    char*pPageBuf = NULL;
    if (!bFileOpen)
        return -1;
    if((rc = FSM.FindForEmptyPage(pageNum)))
    {
        return rc;
    }
    if(pageNum!=NOEMPTYPAGE)
    {
        if ((rc = pBufferMgr->GetPage(osfp,pDataDic->oid,pageNum,&pPageBuf)))
            return rc;
    }
    else
    {
        pageNum = pDataDic->curPageNum;
        Expand();
        if ((rc = pBufferMgr->AllocatePage(osfp,pDataDic->oid,pageNum,&pPageBuf)))
            return rc;
    }
    bHdrChanged ++;
    pageHandle.pageNum = pageNum;
    pageHandle.pPageData = pPageBuf;
    return 0;
}
int FileHandle::DisposePage(int pageNum)
{
    return 0;
}


int FileHandle::MarkDirty(int pageNum) const
{
    if (!bFileOpen)
        return -1;

    if (!IsValidPageNum(pageNum))
        return -1;
    return (pBufferMgr->MarkDirty(pDataDic->oid, pageNum));
}

int FileHandle::UnpinPage(int pageNum) const
{
    if (!bFileOpen)
        return -1;

    if (!IsValidPageNum(pageNum))
        return -1;

    return (pBufferMgr->UnpinPage(pDataDic->oid, pageNum));
}

int  FileHandle::FlushPages()
{
    if (!bFileOpen)
        return -1;
    return (pBufferMgr->FlushPages(pDataDic->oid));
}

int FileHandle::ForcePages(int pageNum) const
{
    if (!bFileOpen)
        return -1;
    return (pBufferMgr->ForcePages(pDataDic->oid, pageNum));
}


int FileHandle::IsValidPageNum(int pageNum) const
{
    return (bFileOpen &&
            pageNum >= 0 &&
            pageNum < Global::pageSize);
}
int FileHandle::Expand()
{
    int numBytes;
    int curPageNum = pDataDic->GetCurPageNum();
    int ph_size = sizeof(PageHeader);
    char * data_chars=NULL;
    char* mid =NULL;
    long offset =(long)( curPageNum*Global::pageSize);
    if(fseek(osfp,offset,0)<0){
        return -1;
    }
    PageHeader phd;
    phd.init();
    data_chars = phd.parseObjToChars();
    mid = new char[Global::pageSize-ph_size];
    memset(mid,0,Global::pageSize-ph_size);
    for(int i=0; i<pDataDic->curPageNum; i++)
    {
        if((numBytes=fwrite(data_chars,ph_size,1,osfp))!=1)
        {
            return -1;
        }

        if((numBytes=fwrite(mid,(Global::pageSize-ph_size)*sizeof(char),1,osfp))!=1)
        {
            return -1;
        }
    }
    delete[] mid;
    mid = NULL;
    FSM.Expand();
    pDataDic->SetCurPageNum(curPageNum*2);
    return 0;
}
