#include "rid.h"

RID::RID()
{
    pageNum = INVALIDPAGE;
    ID = INVALIDID;
}

RID::RID(int pageNum, int ID)
{
    this->pageNum = pageNum;
    this->ID = ID;
}

RID::~RID() {}
RID& RID::operator= (const RID &rid)
{
    if (this != &rid)
    {
        this->pageNum = rid.pageNum;
        this->ID = rid.ID;
    }
    return (*this);
}

bool RID::operator== (const RID &rid) const
{
    return (this->pageNum == rid.pageNum && this->ID == rid.ID);
}
int RID::GetPageNum(int &pageNum) const
{
    pageNum = this->pageNum;
    return 0;
}

int RID::GetID(int &ID) const
{
    ID = this->ID;
    return 0;
}

int RID::isValidRID() const
{
    if(pageNum > 0 && ID >= 0)
        return 0;
    else
        return -1;
}
