#include "buffermgr.h"

BufferMgr::BufferMgr(int numPages)
{
    //ctor
    this->numPages = numPages;
    //Ϊ������˵��������ռ�
    bufTable = new BufferPageDesc[numPages];
    //��ʼ���������Ϊ����������ڴ�
    for (int i = 0; i < numPages; i++)
    {
        if ((bufTable[i].pData = new char[Global::pageSize]) == NULL)
        {
            cerr << "Not enough memory for buffer\n";
            exit(1);
        }
        memset ((void *)bufTable[i].pData, 0, Global::pageSize);
        bufTable[i].prev = i - 1;
        bufTable[i].next = i + 1;
    }
    bufTable[0].prev = bufTable[numPages - 1].next = INVALIDSLOT;
    head_LRU = INVALIDSLOT;
    tail_LRU = INVALIDSLOT;
    freelist_LRU = 0;
}

BufferMgr::~BufferMgr()
{
    //dtor
    for (int i = 0; i < this->numPages; i++)
        delete [] bufTable[i].pData;

    delete [] bufTable;
}


int BufferMgr::GetPage(FILE*fp,int oid, int pageNum, char **ppBuffer,int bMultiplePins)
{
    int rc = 0;
    int slot;
    if (FindInMap(oid, pageNum, slot))
    {
        if ((rc = Alloc_LRU(slot)))
            return rc;
        if ((rc = ReadPage(fp, pageNum, bufTable[slot].pData)) ||
                (rc = InsertInMap(oid, pageNum, slot)) ||
                (rc = InitPageDesc(fp,oid, pageNum, slot)))
        {
            Delete_LRU(slot);
            InsertFree_LRU(slot);
            return rc;
        }
    }
    else
    {
        if (!bMultiplePins && bufTable[slot].pinCount > 0)
            return -1;
        bufTable[slot].pinCount++;
        if ((rc = Delete_LRU(slot)) ||
                (rc = SetHead_LRU(slot)))
            return rc;
    }
    *ppBuffer = bufTable[slot].pData;
    return 0;
}
    //����һ����
int BufferMgr::AllocatePage (FILE* fp,int oid, int pageNum, char **ppBuffer){
   int rc = 0;
   int slot;
   if (!(rc = FindInMap(oid, pageNum, slot)))
      return -1;
   if ((rc = Alloc_LRU(slot)))
      return rc;
   if ((rc = InsertInMap(oid, pageNum, slot)) ||
         (rc = InitPageDesc(fp,oid, pageNum, slot))) {
      Delete_LRU(slot);
      InsertFree_LRU(slot);
      return rc;
   }
   *ppBuffer = bufTable[slot].pData;
   return 0;
}
int BufferMgr::MarkDirty(int oid, int pageNum)
{
    int rc;
    int slot;
    if ((rc = FindInMap(oid, pageNum, slot)))
    {
        return -1;
    }
    //�жϸ�ҳ�Ƿ�д���
    if (bufTable[slot].pinCount == 0)
        return -1;

    //����ҳ˵�����ó���ҳ
    bufTable[slot].beDirty = true;
    //LRU�㷨
    if ((rc = Delete_LRU(slot))||(rc = SetHead_LRU(slot)))
        return rc;
    return 0;
}
int BufferMgr::UnpinPage(int oid, int pageNum)
{
    int  rc = 0;
    int slot;
    if((rc = FindInMap(oid,pageNum,slot)))
    {
        return rc;
    }
    if (bufTable[slot].pinCount == 0)
        return -1;
    if (--(bufTable[slot].pinCount) == 0)
    {
        if ((rc = Delete_LRU(slot))||(rc = SetHead_LRU(slot)))
            return rc;
    }
    return 0;
}
int BufferMgr::FlushPages(int oid)
{
    int rc, rcWarn = 0;
    int slot = head_LRU;
    while (slot != INVALIDSLOT)
    {
        int next = bufTable[slot].next;
        if (bufTable[slot].oid == oid)
        {
            if (bufTable[slot].pinCount)
            {
                rcWarn = -1;
            }
            else
            {
                if (bufTable[slot].beDirty)
                {
                    if ((rc = WritePage(bufTable[slot].fp, bufTable[slot].pageNum, bufTable[slot].pData)))
                        return rc;
                    bufTable[slot].beDirty = false;
                }
                if ((rc = DeleteInMap(bufTable[slot].oid, bufTable[slot].pageNum)) ||
                        (rc = Delete_LRU(slot)) ||
                        (rc = InsertFree_LRU(slot)))
                    return rc;
            }
        }
        slot = next;
    }
    return rcWarn;
}
int BufferMgr::ForcePages(int oid, int pageNum)
{
    int rc = 0;
    int slot = head_LRU;
    while (slot != INVALIDSLOT)
    {
        int next = bufTable[slot].next;
        if (bufTable[slot].oid == oid &&(pageNum==ALL_PAGES || bufTable[slot].pageNum == pageNum))
        {
            if (bufTable[slot].beDirty)
            {
                if ((rc = WritePage(bufTable[slot].fp, bufTable[slot].pageNum, bufTable[slot].pData)))
                    return rc;
                bufTable[slot].beDirty = false;
            }
        }
        slot = next;
    }
    return 0;
}
int BufferMgr::TestOp()
{

    if(InsertInMap(1,1,1)==0)
    {
        cout<<"����ɹ�"<<endl;
    }
    if(InsertInMap(1,2,22)==0)
    {
        cout<<"����ɹ�"<<endl;
    }
    if(InsertInMap(1,2,12)==0)
    {
        cout<<"����ɹ�"<<endl;
    }
    if(InsertInMap(1,3,221)==0)
    {
        cout<<"����ɹ�"<<endl;
    }
    int slot = 0;
    if(FindInMap(1,3,slot)==0)
    {
        cout<<slot<<endl;
    }
    else
    {
        cout<<"���޴˺�!"<<endl;
    }
    if(FindInMap(1,4,slot)==0)
    {
        cout<<slot<<endl;
    }
    else
    {
        cout<<"���޴˺�!"<<endl;
    }
    if(DeleteInMap(1,3)==0)
    {
        cout<<"ɾ���ɹ�"<<endl;
    }
    else
    {
        cout<<"���޴˺�!"<<endl;
    }
    if(DeleteInMap(1,4)==0)
    {
        cout<<"ɾ���ɹ�"<<endl;
    }
    else
    {
        cout<<"���޴˺�!"<<endl;
    }
    if(FindInMap(1,3,slot)==0)
    {
        cout<<slot<<endl;
    }
    else
    {
        cout<<"���޴˺�!"<<endl;
    }
    return 0;
}
int BufferMgr::FindInMap(int oid,int pageNum,int &slot)
{
    stringstream convert;
    convert <<oid<<'_'<<pageNum;
    string oid_pageNum = convert.str();
    map<string, BufferInfo>::iterator it_find;
    it_find = infos_map.find(oid_pageNum);
    if (it_find != infos_map.end())
    {
        struct BufferInfo info;
        info = it_find->second;
        slot = info.slot;
    }
    else
    {
        return -1;
    }
    return 0;
}
int BufferMgr::InsertInMap(int oid,int pageNum,int slot)
{
    stringstream convert;
    convert <<oid<<'_'<<pageNum;
    string oid_pageNum = convert.str();
    map<string, BufferInfo>::iterator it_find;
    it_find = infos_map.find(oid_pageNum);
    if (it_find == infos_map.end())
    {
        struct BufferInfo info;
        info.oid = oid;
        info.pageNum = pageNum;
        info.slot = slot;
        infos_map.insert(pair<string,BufferInfo>(oid_pageNum,info));
    }
    else
    {
        return -1;
    }
    return 0;
}
int BufferMgr::DeleteInMap(int oid,int pageNum)
{
    stringstream convert;
    convert <<oid<<'_'<<pageNum;
    string oid_pageNum = convert.str();
    map<string, BufferInfo>::iterator it_find;
    it_find = infos_map.find(oid_pageNum);
    if (it_find != infos_map.end())
    {
        infos_map.erase(oid_pageNum);
    }
    else
    {
        return -1;
    }
    return 0;
}
int BufferMgr::Alloc_LRU(int &slot)
{
    int rc = 0;
    if (freelist_LRU==INVALIDSLOT)
    {
        slot = freelist_LRU;
        freelist_LRU = bufTable[slot].next;
    }
    else
    {
        for (slot = tail_LRU; slot != INVALIDSLOT; slot = bufTable[slot].prev)
        {
            if (bufTable[slot].pinCount == 0)
                break;
        }
        if (slot == INVALIDSLOT)
            return -1;
        if (bufTable[slot].beDirty)
        {
            if ((rc = WritePage(bufTable[slot].fp, bufTable[slot].pageNum,bufTable[slot].pData)))
                return rc;
            bufTable[slot].beDirty = false;
        }
        if ((rc = DeleteInMap(bufTable[slot].oid, bufTable[slot].pageNum)))
            return rc;
        if((rc = Delete_LRU(slot)))
            return rc;
    }
    if ((rc = SetHead_LRU(slot)))
        return rc;
    return 0;
}
int BufferMgr::Delete_LRU(int slot)
{
    if(slot == head_LRU)
    {
        head_LRU = bufTable[slot].next;
    }
    else
    {
        bufTable[bufTable[slot].prev].next = bufTable[slot].next;
    }
    if(slot == tail_LRU)
    {
        tail_LRU = bufTable[slot].prev;
    }
    else
    {
        bufTable[bufTable[slot].next].prev = bufTable[slot].prev;
    }
    bufTable[slot].next = bufTable[slot].prev = INVALIDSLOT;
    return 0;
}
int BufferMgr::SetHead_LRU(int slot)
{
    bufTable[slot].next = head_LRU;
    bufTable[slot].prev = INVALIDSLOT;
    if (head_LRU != INVALIDSLOT)
        bufTable[head_LRU].prev = slot;
    head_LRU = slot;
    if (tail_LRU == INVALIDSLOT)
        tail_LRU = head_LRU;
    return 0;
}
int BufferMgr::InsertFree_LRU(int slot)
{
    bufTable[slot].next = freelist_LRU;
    freelist_LRU = slot;
    return 0;
}
int BufferMgr::ReadPage(FILE* fp,int pageNum, char *dest)
{
    long offset =(long)(pageNum * Global::pageSize);
    if (fseek(fp, offset, SEEK_SET) < 0)
        return -1;
    int numBytes = fread(dest,Global::pageSize,1,fp);
    if (numBytes != 1)
        return -1;
    return 0;
}
int BufferMgr::WritePage(FILE* fp,int pageNum, char *source)
{
    long offset = (long)(pageNum * Global::pageSize);
    if (fseek(fp, offset, SEEK_SET) < 0)
        return -1;
    int numBytes = fwrite( source, Global::pageSize,1,fp);
    if (numBytes < 0)
        return -1;
    return 0;
}
int BufferMgr::InitPageDesc(FILE* fp,int oid,int pageNum, int slot)
{
    bufTable[slot].oid = oid;
    bufTable[slot].fp = fp;
    bufTable[slot].pageNum  = pageNum;
    bufTable[slot].beDirty   = false;
    bufTable[slot].pinCount = 1;
    return 0;
}
