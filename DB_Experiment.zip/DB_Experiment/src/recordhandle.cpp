#include "recordhandle.h"

RecordHandle::RecordHandle(DataDic *pDataDic):pDataDic(pDataDic),fileHandle(pDataDic)
{
    //ctor
}

RecordHandle::~RecordHandle()
{
    //dtor
}
