#include "recordmgr.h"

RecordMgr::RecordMgr(FileMgr &fmgr) : fmgr(fmgr)
{
}

RecordMgr::~RecordMgr()
{
}
int RecordMgr::CreateFile (const char *fileName,DataDic& dataDic)
{
    int rc = 0;
    if(fileName == NULL)
        return -1;
    if((rc = fmgr.CreateFile(fileName,dataDic)))
        return rc;
    return 0;
}

int RecordMgr::DestroyFile(const char *fileName)
{
    if(fileName == NULL)
        return -1;
    int rc;
    if((rc = fmgr.DestroyFile(fileName)))
        return rc;
    return 0;
}

int RecordMgr::OpenFile(const char *fileName, RecordHandle &recordHandle,DataDic &dataDic)
{
    if(fileName == NULL)
        return -1;
    if(recordHandle.openedFH == true)
        return -1;
    //初始化RecordHandle的内容
    recordHandle.openedFH = true;
    int rc;
    if((rc = fmgr.OpenFile(fileName, recordHandle.fileHandle,dataDic)))
        return rc;

    return 0;
}
int RecordMgr::CloseFile(RecordHandle &recordHandle)
{
    int rc;
    if(recordHandle.openedFH == false)
        return -1;
    //清理RecordHandle的内容
    recordHandle.openedFH = false;
    if((rc = fmgr.CloseFile(recordHandle.fileHandle)))
        return rc;
    return 0;
}
