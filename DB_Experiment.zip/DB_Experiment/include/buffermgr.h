#ifndef BUFFERMGR_H
#define BUFFERMGR_H
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <sstream>
#include <string>
#include <iostream>
#include <string.h>

#include"global.h"
#define INVALIDSLOT -1

using namespace std;
//���� oid+pageNum��slot��ӳ�����
struct BufferInfo
{
    int oid;
    int pageNum;
    int slot;
};
//�����������
struct BufferPageDesc
{
    //ҳ����
    char *pData;
    //��һ�ڵ�˵��
    int next;
    //��һ�ڵ�˵��
    int prev;
    //�Ƿ�����ҳ
    bool beDirty;
    //pin����
    int pinCount;
    int oid;
    int pageNum;
    FILE* fp;
};

class BufferMgr
{
public:
    BufferMgr(int numPages);
    virtual ~BufferMgr();
    int GetPage(FILE* fp,int oid, int pageNum, char **ppBuffer,int bMultiplePins = 1);
    //����һ����
    int  AllocatePage (FILE* fp,int oid, int pageNum, char **ppBuffer);
    //��ҳ���ó���ҳ
    int MarkDirty(int oid, int pageNum);
    //д��ѡ��ҳ
    int UnpinPage(int oid, int pageNum);
    //д��ĳһ��������ҳ
    int FlushPages(int oid);
    //д��ѡ��ҳ
    int ForcePages(int oid, int pageNum = ALL_PAGES);

    int TestOp();
private:
    int numPages;
    BufferPageDesc* bufTable;

    map<string,BufferInfo> infos_map;
    int FindInMap(int oid,int pageNum,int &slot);
    int InsertInMap(int oid,int pageNum,int slot);
    int DeleteInMap(int oid,int pageNum);

    int head_LRU;
    int tail_LRU;
    int freelist_LRU;
    int Alloc_LRU(int &slot);
    int Delete_LRU(int slot);
    int SetHead_LRU(int slot);
    int InsertFree_LRU(int slot);

    int ReadPage(FILE* fp,int pageNum, char *dest);
    int WritePage(FILE* fp,int pageNum, char *source);
    int InitPageDesc(FILE* fp,int oid,int pageNum, int slot);
};

#endif // BUFFERMGR_H
