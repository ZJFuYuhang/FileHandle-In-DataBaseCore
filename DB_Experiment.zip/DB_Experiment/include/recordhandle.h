#ifndef RECORDHANDLE_H
#define RECORDHANDLE_H

#include "global.h"
#include "filehandle.h"
#include "datadic.h"
#include "rid.h"
class RecordHandle
{
    friend class RecordMgr;
public:
    RecordHandle(DataDic *pDataDic);
    virtual ~RecordHandle();
    int InsertRec(const char *pData, RID &rid);

private:
    DataDic *pDataDic;
    FileHandle fileHandle;
    bool openedFH;
};

#endif // RECORDHANDLE_H
