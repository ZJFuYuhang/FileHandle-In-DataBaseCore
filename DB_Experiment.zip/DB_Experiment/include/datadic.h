#ifndef DATADIC_H
#define DATADIC_H


class DataDic
{
    friend class FileMgr;
    friend class FileHandle;
public:
    DataDic(int oid,const char* fileName);
    virtual ~DataDic();
public:
    int GetCurPageNum(){return curPageNum;}
    void SetCurPageNum(int curPageNum){this->curPageNum = curPageNum;}
    const char* GetFileName(){return fileName;}
private:
    int curPageNum;
    const int oid;                        //��ǰ�ļ���ҳ����
    const char* fileName;
};

#endif // DATADIC_H
