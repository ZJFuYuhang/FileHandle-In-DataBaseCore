#ifndef FILEHANDLE_H
#define FILEHANDLE_H


#include "pagehandle.h"
#include "filemgr.h"
#include "buffermgr.h"
#include "fsmapping.h"
#include "datadic.h"
#include "global.h"

#include <stdio.h>
using namespace std;
class FileHandle
{
    friend class FileMgr;
public:
    FileHandle(DataDic*);
    virtual ~FileHandle();
public:
    //��������
    FileHandle  (const FileHandle &fileHandle);

    //=����
    FileHandle& operator=(const FileHandle &fileHandle);

    int GetFirstPage(PageHandle &pageHandle) const;
    int GetNextPage (int current, PageHandle &pageHandle) const;
    int GetThisPage (int pageNum, PageHandle &pageHandle) const;
    int GetLastPage(PageHandle &pageHandle) const;
    int GetPrevPage (int current, PageHandle &pageHandle) const;

    int AllocatePage(PageHandle &pageHandle);
    int DisposePage(int pageNum);
    int MarkDirty(int pageNum) const;
    int UnpinPage(int pageNum) const;
    int ForcePages(int pageNum=ALL_PAGES) const;
    int FlushPages();
    int IsValidPageNum(int pageNum) const;
protected:
    int Expand();
private:
    FILE* osfp;
    int bHdrChanged;
    bool bFileOpen;
    FSMapping FSM;
    DataDic* pDataDic;
    BufferMgr *pBufferMgr;
};

#endif // FILEHANDLE_H
