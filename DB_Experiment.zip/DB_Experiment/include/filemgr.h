#ifndef FILEMGR_H
#define FILEMGR_H

#include "filehandle.h"
#include "datastruct.h"
#include "buffermgr.h"
#include "global.h"
#include "datadic.h"

#include <iostream>
#include <stdio.h>
#include <string>
#include <io.h>
#include <string.h>
using namespace std;

class FileHandle;
class FileMgr
{
public:
    FileMgr();
    virtual ~FileMgr();
    int CreateFile(const char *fileName,DataDic& dataDic);
    int DestroyFile(const char *fileName);
    int OpenFile (const char *fileName, FileHandle &fileHandle,DataDic &dataDic);
    int CloseFile(FileHandle &fileHandle);
protected:

private:
    BufferMgr* pBufferMgr;
};

#endif // FILEMGR_H
