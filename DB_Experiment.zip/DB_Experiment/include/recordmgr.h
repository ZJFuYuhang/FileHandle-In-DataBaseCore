#ifndef RECORDMGR_H
#define RECORDMGR_H
#include "global.h"
#include "filehandle.h"
#include "filemgr.h"
#include "recordhandle.h"
#include "datadic.h"

class RecordMgr
{
public:
    RecordMgr(FileMgr &fmgr);
    ~RecordMgr();
    int CreateFile (const char *fileName,DataDic& dataDi);
    int DestroyFile(const char *fileName);
    int OpenFile   (const char *fileName, RecordHandle &fileHandle,DataDic &dataDi);
    int CloseFile  (RecordHandle &fileHandle);
private:
    FileMgr &fmgr;
};
#endif // RECORDMGR_H
