#ifndef RID_H
#define RID_H
#include "global.h"

class RID
{
    static const int INVALIDPAGE = -1;
    static const int INVALIDID = -1;
public:
    RID();
    RID(int pageNum, int ID);
    ~RID();
    RID& operator= (const RID &rid);
    bool operator== (const RID &rid) const;
    int GetPageNum(int &pageNum) const;
    int GetID(int &ID) const;
    int isValidRID() const;
private:
    int pageNum;
    int ID;
};

#endif // RID_H
