
#include <iostream>
#include "buffermgr.h"
using namespace std;

int main()
{
    return 0;
}

























//#include <iostream>
//#include "datadic.h"
//#include "filemgr.h"
//#include "filehandle.h"
//using namespace std;

//int main()
//{
//    return 0;
//}








//
//int main()
//{
//    DataDic dataDic(1,"mydb_1");
//    FileMgr fileMgr;
//    FileHandle fileHandle(&dataDic);
//    fileMgr.CreateFile(dataDic.GetFileName(),dataDic);
//    fileMgr.OpenFile(dataDic.GetFileName(),fileHandle,dataDic);
//    fileMgr.CloseFile(fileHandle);
//    return 0;
//}













